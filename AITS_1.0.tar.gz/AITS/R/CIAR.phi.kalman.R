CIAR.phi.kalman <-
function(x,y,t,yerr,zero.mean='TRUE',standarized='TRUE',c=1)
{
	sigmay<-1
	if(standarized=='FALSE')
		sigmay<-var(y)
	if(zero.mean=='FALSE')
		y=y-mean(y)
    n=length(y)
    Sighat=sigmay*matrix(c(1,0,0,c),2,2)
    xhat=matrix(0,nr=2,nc=n)
    delta<-diff(t)
    Q=Sighat
    phi.R=x[1]
    phi.I=x[2]
    #DEFINITION OF F
    F=matrix(0,nr=2,nc=2)
    G=matrix(0,nr=1,nc=2)
    G[1,1]=1
    #MOD PHI MUST BE LESS THAN ONE
    phi=complex(1,real=phi.R,imag=phi.I)
    Phi=Mod(phi)
    psi<-acos(phi.R/Phi)
    sum.Lambda=0
    sum.error=0
    phi=ifelse(is.na(phi)==TRUE,1.1,phi)
    if(Mod(phi)<1){
    for(i in 1:(n-1))
    	{
            Lambda=G%*%Sighat%*%t(G) + yerr[i+1]**2
            if(Lambda<=0 | is.na(Lambda)==TRUE)
			{
	            sum.Lambda<-n*1e10
				break;
			}
     phi2.R<-(Phi**delta[i])*cos(delta[i]*psi)
     phi2.I<-(Phi**delta[i])*sin(delta[i]*psi)
     F[1,1]=phi2.R
     F[1,2]=-phi2.I
     F[2,1]=phi2.I
     F[2,2]=phi2.R
     phi2<-1-Mod(phi**delta[i])**2
     Qt<-phi2*Q
     sum.Lambda=sum.Lambda+log(Lambda)
     Theta=F%*%Sighat%*%t(G)
     sum.error= sum.error+ ( y[i]-G%*%xhat[,i] )**2/Lambda
     xhat[,i+1]=F%*%xhat[,i]+Theta%*%solve(Lambda)%*%(y[i]-G%*%xhat[,i])
     Sighat=F%*%Sighat%*%t(F)+ Qt - Theta%*%solve(Lambda)%*%t(Theta)
     }
     yhat=G%*%xhat
     out<-ifelse(is.na(sum.Lambda)==TRUE,1e10,(sum.Lambda + sum.error)/n)
     }
  	 else out=1e10
     return(out)
}
