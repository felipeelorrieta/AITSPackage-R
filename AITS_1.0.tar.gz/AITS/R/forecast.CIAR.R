forecast.CIAR <-
function(phi.R,phi.I,y1,st,n.ahead=1)
{
		yhat=predict.CIAR(x=c(phi.R,phi.I),y=y1,t=st)
		n=length(yhat$yhat)
		xhat=yhat$xhat
		Theta=yhat$Theta
		Lambda=yhat$Lambda
		Sighat=yhat$Sighat
		Qt=yhat$Qt
        F=matrix(0,nr=2,nc=2)
        G=matrix(0,nr=1,nc=2)
        G[1,1]=1
		phi=complex(1,real=phi.R,imag=phi.I)
		Phi=Mod(phi)
		phi=ifelse(is.na(phi)==TRUE,1.1,phi)
        if(Mod(phi)>=1)
                stop("Mod of Phi must be less than one")
        psi<-acos(phi.R/Phi)
        delta=n.ahead
		phi2.R<-(Phi**delta)*cos(delta*psi)
        phi2.I<-(Phi**delta)*sin(delta*psi)
        yhat1=rep(0,length(n.ahead))
		xhat1=matrix(0,nr=2,nc=length(n.ahead))
		Lambda2=rep(0,length(n.ahead))
        for(i in 1:length(n.ahead))
        {
        	F[1,1]=phi2.R[i]
        	F[1,2]=-phi2.I[i]
        	F[2,1]=phi2.I[i]
        	F[2,2]=phi2.R[i]
			xhat1[,i]=F%*%xhat[,n] +Theta%*%solve(Lambda)%*%(y1[n]-G%*%xhat[,n])
			yhat1[i]=G%*%xhat1[,i]
			Sighat2=F%*%Sighat%*%t(F)+ Qt - Theta%*%solve(Lambda)%*%t(Theta) #R_t es 0
			Lambda2[i]=G%*%Sighat2%*%t(G)
		}
		return(list(fitted=yhat$yhat,forecast=yhat1,Lambda=Lambda2,Sighat=Sighat2))
}
