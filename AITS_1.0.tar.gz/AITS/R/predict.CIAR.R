predict.CIAR <-
function(x,y,t,standarized='TRUE',c=1)
{
        sigmay<-1
        if(standarized=='FALSE')
                sigmay<-var(y)
	n=length(y)
        Sighat=sigmay*matrix(c(1,0,0,c),2,2)
        xhat=matrix(0,nr=2,nc=n)
        delta<-diff(t)
        Q=Sighat
        phi.R=x[1]
        phi.I=x[2]
        #DEFINITION OF F
        F=matrix(0,nr=2,nc=2)
        G=matrix(0,nr=1,nc=2)
        G[1,1]=1
        #MOD PHI MUST BE LESS THAN ONE
        phi=complex(1,real=phi.R,imag=phi.I)
        Phi=Mod(phi)
	phi=ifelse(is.na(phi)==TRUE,1.1,phi)
        if(Mod(phi)>=1)
                stop("Mod of Phi must be less than one")
        psi<-acos(phi.R/Phi)
        if(Mod(phi)<1){
        for(i in 1:(n-1))
                {
                        Lambda=G%*%Sighat%*%t(G) #R_t es 0
                        if(Lambda<=0 | is.na(Lambda)==TRUE)
                                break;
                        phi2.R<-(Phi**delta[i])*cos(delta[i]*psi)
                        phi2.I<-(Phi**delta[i])*sin(delta[i]*psi)
                        F[1,1]=phi2.R
                        F[1,2]=-phi2.I
                        F[2,1]=phi2.I
                        F[2,2]=phi2.R
                        phi2<-1-Mod(phi**delta[i])**2
                        Qt<-phi2*Q
                        Theta=F%*%Sighat%*%t(G)
                        xhat[,i+1]=F%*%xhat[,i]+Theta%*%solve(Lambda)%*%(y[i]-G%*%xhat[,i])
                        Sighat=F%*%Sighat%*%t(F)+ Qt - Theta%*%solve(Lambda)%*%t(Theta)
                }
            yhat=G%*%xhat
        }
        return(list(yhat=yhat,xhat=xhat,Sighat=Sighat,Theta=Theta,Lambda=Lambda,Qt=Qt))
}
