IAR.phi.t <-
function (x, y, sT, nu=3) #Minus Log Full Likelihood Function
{
    sigma=x[2]
    x=x[1]
    n = length(y)
    d <- diff(sT)
    xd=x**d
    yhat = xd * y[-n]  #Mean of conditional distribution
    gL=sigma*(1-xd**(2))*((nu-2)/nu)  #Variance of conditional distribution
    cte = (n-1)*log((gamma((nu+1)/2)/(gamma(nu/2)*sqrt(nu*pi))))
    stand=((y[-1]-yhat)/sqrt(gL))**2
    s1=sum(0.5*log(gL))
    s2=sum(log(1 + (1/nu)*stand))
    out= cte - s1 - ((nu+1)/2)*s2 -0.5*(log(2*pi) + y[1]**2)
    out=-out #-Log Likelihood (We want to minimize it)
    return(out)
}
