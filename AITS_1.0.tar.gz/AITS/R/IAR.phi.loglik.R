IAR.phi.loglik <-
function(x,y,sT,standarized='TRUE')
{
 sigma=1
 if(standarized=='FALSE')
	sigma=var(y)
 n=length(y)
 d<-diff(sT)
 phi=x**d
 yhat=phi*y[-n]
 cte=(n/2)*log(2*pi)
 s1=cte+0.5*sum(log(sigma*(1-phi**2))+(y[-1]-yhat)**2/(sigma*(1-phi**2)))
 return(s1)
}
