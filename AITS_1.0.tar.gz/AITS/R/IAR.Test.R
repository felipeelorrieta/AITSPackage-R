IAR.Test <-
function(y,sT,f,phi,plot='TRUE',xlim=c(-1,0))
{
      aux=seq(2.5,47.5,by=2.5)
      aux=c(-aux,aux)
      aux=sort(aux)
      f0=f*(1+aux/100)
      f0<-sort(f0)
      l1<-length(f0)
      bad<-rep(0,l1)
      data<-cbind(sT,y)
      for(j in 1:l1)
      {
        results=harmonicfit(file=data,f1=f0[j])
        y=results$res/sqrt(var(results$res))
        sT=results$t
        res3=IAR.loglik(y,sT)[1]
        bad[j]=res3$phi
      }
      mubf<-mean(log(bad))
      sdbf<-sd(log(bad))
      z0<-log(phi)
      pvalue<-pnorm(z0,mubf,sdbf)
      out<-NULL
      if(plot=='TRUE')
      {
      	phi2=bad
      	phi2<-as.data.frame(phi2)
		phi<-as.data.frame(phi)
		out<-ggplot(phi2,aes(log(phi2)))+geom_density(adjust=2)+xlab("")		+ylab("")+theme_bw()+ggtitle("")+geom_point(data = phi,aes(log(phi)), y = 0, size = 4,col='red',shape=17) + xlim(xlim[1],xlim[2])+
        theme(plot.title = element_text(face="bold", size=20),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_blank())
        out
      }
     return(list(phi=phi,norm=c(mubf,sdbf),z0=z0,pvalue=pvalue,out=out))
}
