IAR.phi.kalman <-
function(x,y,yerr,t,zero.mean='TRUE',standarized='TRUE')
{	
		sigmay<-1
		if(standarized=='FALSE')
			sigmay<-var(y)
		if(zero.mean=='FALSE')
			y=y-mean(y)
        n=length(y)
        Sighat=sigmay*diag(1)
        xhat=matrix(0,nr=1,nc=n)
        delta<-diff(t)
        Q=Sighat
        phi=x
        #DEFINITION OF F
        F=matrix(0,nr=1,nc=1)
        G=matrix(0,nr=1,nc=1)
        G[1,1]=1
        #MOD PHI MUST BE LESS THAN ONE
        sum.Lambda=0
        sum.error=0
        phi=ifelse(is.na(phi)==TRUE,1.1,phi)
        if(abs(phi)<1){
        for(i in 1:(n-1))
        {
                Lambda=G%*%Sighat%*%t(G) + yerr[i+1]**2
            	if(Lambda<=0 | is.na(Lambda)==TRUE)
				{
	            	sum.Lambda<-n*1e10
					break;
				}
                phi2<-phi**delta[i]
                F[1,1]=phi2
                phi2<-1-phi**(2*delta[i])
                Qt<-phi2*Q
                sum.Lambda=sum.Lambda+log(Lambda)
                Theta=F%*%Sighat%*%t(G)
                sum.error= sum.error+ ( y[i]-G%*%xhat[,i] )**2/Lambda
                xhat[,i+1]=F%*%xhat[,i]+Theta%*%solve(Lambda)%*%(y[i]-G%*%xhat[,i])
                Sighat=F%*%Sighat%*%t(F)+ Qt - Theta%*%solve(Lambda)%*%t(Theta)
        }
        yhat=G%*%xhat
        out<-ifelse(is.na(sum.Lambda)==TRUE,1e10,(sum.Lambda + sum.error)/n)
  }
  else out=1e10
  return(out)
}
