IARg.sample <-
function(n,phi,st,sigma2=1,mu=1)
{
        delta<-diff(st) #Times differences
        y <- vector("numeric", n)
        y[1] <- rgamma(1,shape=1,scale=1) #initialization
        shape<-rep(0,n)
        scale<-rep(0,n)
        yhat<-rep(0,n)
        for (i in 2:n)
        {
        phid=phi**(delta[i-1]) #Expected Value Conditional Distribution
        yhat[i] = mu+phid * y[i-1]  #Mean of conditional distribution
        gL=sigma2*(1-phid**(2)) #Variance Value Conditional Distribution
        shape[i]=yhat[i]**2/gL
        scale[i]=(gL/yhat[i])
        y[i] <- rgamma(1,shape=shape[i], scale=scale[i])#Conditional Gamma IAR
        }
        #ts.plot(yhat)
        return(list(y=y,st=st))
}
