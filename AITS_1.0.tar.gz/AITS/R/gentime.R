gentime <-
function(n,lambda1=130,lambda2=6.5,p1=0.15,p2=0.85)
{
	dT<-rep(0,n)
	a<-sample(c(lambda1,lambda2),size=n,prob=c(p1,p2),replace=TRUE)
	dT[which(a==lambda1)]=rexp(length(which(a==lambda1)),rate=1/lambda1)
	dT[which(a==lambda2)]=rexp(length(which(a==lambda2)),rate=1/lambda2)
	sT=cumsum(dT)
	return(sT)
}
