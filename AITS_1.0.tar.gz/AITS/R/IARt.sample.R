IARt.sample <-
function(n,phi,st,sigma2=1,nu=3)
{
        delta<-diff(st) #Times differences
		y <- vector("numeric", n)
        y[1] <- rnorm(1) #initialization
        for (i in 2:n)
        {
                phid=phi**(delta[i-1]) #Expected Value Conditional Distribution
                yhat = phid * y[i-1]  #Mean of conditional distribution
                gL=sigma2*(1-phid**(2)) #Variance Value Conditional Distribution
                y[i] <- rt(1, df=nu)*sqrt(gL * (nu-2)/nu) + yhat #Conditional-t IAR
        }
      	return(list(y=y,st=st))
}
