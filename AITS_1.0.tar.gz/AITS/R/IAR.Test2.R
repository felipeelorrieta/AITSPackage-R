IAR.Test2 <-
function(y,sT,iter=100,phi,plot='TRUE',xlim=c(-1,0))
{
	phi2=rep(0,iter)
	for(i in 1:iter)
	{
		ord<-sample(1:length(y))
		y1<-y[ord]
		phi2[i]=IAR.loglik(y=y1,sT=sT)$phi
	}
    mubf<-mean(log(phi2))
    sdbf<-sd(log(phi2))
    z0<-log(phi)
    pvalue<-pnorm(z0,mubf,sdbf)
    out<-NULL
    if(plot=='TRUE')
    {
    	phi2<-as.data.frame(phi2)
		phi<-as.data.frame(phi)
		out<-ggplot(phi2,aes(log(phi2)))+geom_density(adjust=2)+xlab("")		+ylab("")+theme_bw()+ggtitle("")+geom_point(data = phi,aes(log(phi)), y = 0, size = 4,col='red',shape=17) + xlim(xlim[1],xlim[2])+
        theme(plot.title = element_text(face="bold", size=20),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_blank())
        out
      } 
return(list(phi=phi,norm=c(mubf,sdbf),z0=z0,pvalue=pvalue,out=out))
}
