harmonicfit <-
function(file,f1,nham=4,weights=NULL,print=FALSE){
        mycurve=file
        t=mycurve[,1]
        y=residuals(lm(mycurve[,2]~t))
        y=y
        for(i in 1:nham)
        {
        	y=cbind(y,sin(2*i*pi*f1*t),cos(2*i*pi*f1*t))	
        }
        df=data.frame(y)
        model=lm(y~.,data=df)
        if(length(weights)>0)
        		model=lm(y~.,data=df,weights=weights)
        if(print == TRUE)
        		print(summary(model))
        res=residuals(model)     
        R2<-summary(model)$adj.r.squared
        MSE<-anova(model)$"Mean Sq"[nham*2+1]
	    return(list(res=res,t=t,R2=R2,MSE=MSE))
}
