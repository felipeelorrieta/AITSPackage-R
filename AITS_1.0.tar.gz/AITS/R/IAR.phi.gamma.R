IAR.phi.gamma <-
function (x, y, sT) #Minus Log Full Likelihood Function
{
    mu=x[2]
    sigma=x[3]
    x=x[1]
    n = length(y)
    d <- diff(sT)
    xd=x**d
    yhat = mu+xd * y[-n]  #Mean of conditional distribution
    gL=sigma*(1-xd**(2))  #Variance of conditional distribution
    beta=gL/yhat #Beta parameter of gamma distribution
    alpha=yhat**2/gL #Alpha parameter of gamma distribution
    out=sum((-alpha)*log(beta) - lgamma(alpha) - y[-1]/beta + (alpha-1)*log(y[-1])) - y[1]  #Full Log Likelihood
    out=-out #-Log Likelihood (We want to minimize it)
    return(out)
}
