CIAR.kalman <-
function(y,t,delta=0,zero.mean='TRUE',standarized='TRUE',c=1,niter=10,seed=1234)
{
	set.seed(seed)
    aux<-1e10
	value<-1e10
    br<-0
    if(sum(delta)==0){
		delta=rep(0,length(y))}
    for(i in 1:niter)
    {
         phi.R=2*runif(1)-1
         phi.I=2*runif(1)-1
         #print(complex(1,real=phi.R,imag=phi.I))
         if(Mod(complex(1,real=phi.R,imag=phi.I))<1)
         {
         	optim<-nlminb(start=c(phi.R,phi.I),obj=CIAR.phi.kalman,y=y,t=t,yerr=delta,zero.mean=zero.mean,standarized=standarized,c=c,lower=c(-1,-1),upper=c(1,1))
            value<-optim$objective
          }
          if(aux>value)
          {
          	par<-optim$par
          	aux<-value
            br<-br+1
           }
           if(aux<=value & br>1 & i>trunc(niter/2))
           	break;
     }
     if(aux==1e10)
     	par<-c(0,0)
     return(list(phiR=par[1],phiI=par[2],ll=aux))
}
