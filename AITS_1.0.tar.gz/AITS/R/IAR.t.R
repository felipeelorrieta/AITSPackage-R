IAR.t <-
function (y, sT,nu=3) #Find minimum of IAR.phi.gamma
{
        aux<-1e10
        value<-1e10
        br<-0
        for(i in 1:20)
        {
                phi=runif(1)
                sigma=var(y)*runif(1)
                optim<-nlminb(start=c(phi,sigma),obj=IAR.phi.t,y=y,sT=sT,nu=nu,lower=c(0,0.0001),upper=c(0.9999,2*var(y)))
                value<-optim$objective
                #print(c(optim$objective,optim$par,aux>value))
                if(aux>value)
                {
                        par<-optim$par
                        aux<-value
                        br<-br+1
                }
                if(aux<=value & br>10 & i>15)
                        break;
        }
        if(aux==1e10)
        par<-c(0,0)
        return(list(phi=par[1],sigma=par[2],ll=aux))
}
