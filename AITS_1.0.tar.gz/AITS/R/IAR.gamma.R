IAR.gamma <-
function(y, sT)
{
        aux<-1e10
        value<-1e10
        br<-0
        for(i in 1:20)
        {
                phi=runif(1)
                mu=mean(y)*runif(1)
                sigma=var(y)*runif(1)
			optim<-nlminb(start=c(phi,mu,sigma),obj=IAR.phi.gamma,y=y,sT=sT,lower=c(0,0.0001,0.0001),upper=c(0.9999,mean(y),var(y)))
                value<-optim$objective
                if(aux>value)
                {
                        par<-optim$par
                        aux<-value
                        br<-br+1
                }
                if(aux<=value & br>5 & i>10)
                        break;
        }
        if(aux==1e10)
                par<-c(0,0,0)
        return(list(phi=par[1],mu=par[2],sigma=par[3],ll=aux))
}
