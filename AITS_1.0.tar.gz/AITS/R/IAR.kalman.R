IAR.kalman <-
function (y, sT, delta=0,zero.mean='TRUE',standarized='TRUE')
{
	if(sum(delta)==0){
		delta=rep(0,length(y))}
    out = optimize(IAR.phi.kalman, interval = c(0, 1), y = y, t = sT, yerr=delta,zero.mean=zero.mean,standarized=standarized)
    phi = out$minimum
    ll = out$objective
    return(list(phi = phi, kalman = ll))
}
