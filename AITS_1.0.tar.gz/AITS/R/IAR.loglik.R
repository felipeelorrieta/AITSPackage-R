IAR.loglik <-
function(y,sT,standarized='TRUE'){
out=optimize(IAR.phi.loglik,interval=c(0,1),y=y,sT=sT,standarized=standarized)
 phi=out$minimum
 ll=out$objective
 return(list(phi=phi,loglik=ll))
}
